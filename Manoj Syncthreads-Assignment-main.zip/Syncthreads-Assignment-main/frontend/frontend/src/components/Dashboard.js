import React, { useState, useEffect } from "react";
import "./Dashboard.css"; // Importing the CSS file

const Dashboard = () => {
    const [locations, setLocations] = useState([]);
    const token = localStorage.getItem("token");

    useEffect(() => {
        fetch("http://localhost:5000/api/dashboard", {
            method: "GET",
            headers: { "Authorization": `Bearer ${token}` },
        })
        .then(response => response.json())
        .then(data => {
            setLocations(data);
        })
        .catch(error => console.error("Error:", error));
    }, []);

    return (
        <div className="dashboard-container">
            <h1 className="dashboard-title">Dashboard</h1>
            <div className="locations-list">
                {locations.map((location) => (
                    <div className="location-item" key={location.id}>
                        <a href={`/map/${location.id}`} className="location-link">
                            {location.title}
                        </a> 
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Dashboard;
